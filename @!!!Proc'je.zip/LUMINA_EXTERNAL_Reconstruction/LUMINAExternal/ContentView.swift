import SwiftUI
import AVKit

@main
struct LUMINAExternalApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

struct ContentView: View {
    @State private var selectedGame = "Free Fire"
    @State private var showInfo = false
    private let blue = Color(red: 0.16, green: 0.55, blue: 1.0)
    private let games = ["Free Fire", "Free Fire MAX"]

    var body: some View {
        ZStack {
            Color(red: 0.025, green: 0.04, blue: 0.075).ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {
                    header
                    hero
                    VStack(alignment: .leading, spacing: 12) {
                        Text("SELECT GAME").font(.system(size: 12, weight: .bold, design: .rounded)).tracking(2).foregroundStyle(.white.opacity(0.55))
                        ForEach(games, id: \.self) { game in
                            Button { selectedGame = game } label: {
                                HStack(spacing: 14) {
                                    Image(systemName: "gamecontroller.fill").font(.title2).foregroundStyle(blue)
                                        .frame(width: 48, height: 48).background(blue.opacity(0.13)).clipShape(RoundedRectangle(cornerRadius: 14))
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(game).font(.system(size: 16, weight: .semibold)).foregroundStyle(.white)
                                        Text(game == selectedGame ? "Selected" : "Tap to select").font(.caption).foregroundStyle(.white.opacity(0.48))
                                    }
                                    Spacer()
                                    Image(systemName: game == selectedGame ? "checkmark.circle.fill" : "circle")
                                        .foregroundStyle(game == selectedGame ? blue : .white.opacity(0.25)).font(.title3)
                                }.padding(14).background(Color.white.opacity(0.045)).overlay(RoundedRectangle(cornerRadius: 18).stroke(game == selectedGame ? blue.opacity(0.8) : .white.opacity(0.08), lineWidth: 1)).clipShape(RoundedRectangle(cornerRadius: 18))
                            }.buttonStyle(.plain)
                        }
                    }
                    Button { showInfo = true } label: {
                        HStack { Image(systemName: "info.circle.fill"); Text("PROJECT INFORMATION"); Spacer(); Image(systemName: "arrow.up.right") }
                            .font(.system(size: 13, weight: .bold)).tracking(1).foregroundStyle(.white)
                            .padding(17).background(blue.opacity(0.17)).clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                    Text("RECONSTRUCTED UI • ORIGINAL SOURCE NOT INCLUDED")
                        .font(.system(size: 9, weight: .medium, design: .monospaced)).tracking(1).foregroundStyle(.white.opacity(0.32)).multilineTextAlignment(.center)
                }.padding(20)
            }
        }
        .preferredColorScheme(.dark)
        .alert("About this reconstruction", isPresented: $showInfo) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("This Xcode starter project contains recoverable media and localization resources from the supplied IPA plus a new SwiftUI interface. The original compiled implementation cannot be restored exactly from an IPA. Injection, exploit, key validation, and server features are not implemented.")
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image("KernelLogo").resizable().scaledToFit().frame(width: 46, height: 46).clipShape(RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 3) {
                Text("LUMINA").font(.system(size: 21, weight: .black, design: .rounded)).tracking(2).foregroundStyle(.white)
                Text("EXTERNAL  •  RECONSTRUCTION").font(.system(size: 9, weight: .bold, design: .monospaced)).tracking(1.4).foregroundStyle(blue)
            }
            Spacer()
            Image(systemName: "circle.hexagongrid.fill").font(.title2).foregroundStyle(blue)
        }.padding(.top, 8)
    }

    private var hero: some View {
        ZStack(alignment: .bottomLeading) {
            RoundedRectangle(cornerRadius: 24).fill(LinearGradient(colors: [Color(red: 0.05, green: 0.22, blue: 0.45), Color(red: 0.04, green: 0.07, blue: 0.15), .black], startPoint: .topLeading, endPoint: .bottomTrailing))
            Circle().fill(blue.opacity(0.22)).frame(width: 190).blur(radius: 35).offset(x: 170, y: -55)
            VStack(alignment: .leading, spacing: 12) {
                Text("WELCOME TO").font(.system(size: 11, weight: .bold, design: .rounded)).tracking(3).foregroundStyle(.white.opacity(0.6))
                Text("LUMINA\nEXTERNAL").font(.system(size: 34, weight: .black, design: .rounded)).tracking(1).lineSpacing(-2).foregroundStyle(.white)
                Text("A recreated interface project for iOS").font(.system(size: 13, weight: .medium)).foregroundStyle(.white.opacity(0.65))
                HStack(spacing: 7) { Circle().fill(.orange).frame(width: 7, height: 7); Text("DEVELOPMENT BUILD").font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(1.2).foregroundStyle(.white.opacity(0.8)) }
                    .padding(.horizontal, 11).padding(.vertical, 8).background(.white.opacity(0.08)).clipShape(Capsule())
            }.padding(24)
        }.frame(height: 250).clipShape(RoundedRectangle(cornerRadius: 24)).overlay(RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.1), lineWidth: 1))
    }
}
