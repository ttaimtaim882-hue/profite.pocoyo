# LUMINA External — Xcode Reconstruction Starter

This project combines recoverable resources from the supplied `LUMINA_EXTERNAL(4).ipa` with a newly written SwiftUI interface.

## Included
- Recreated SwiftUI landing/dashboard screen
- Original app icon and kernel logo image
- Two bundled MP4 background assets
- Extracted localization strings for English, Arabic, Russian, and Bengali
- App metadata from the IPA (documented separately below)

## Important limitations
An IPA normally contains a compiled executable, not the original Swift/Objective-C project. The exact original source, Xcode project settings, server-side code, signing credentials, and build dependencies cannot be reconstructed reliably from the binary alone. This is a starter reconstruction, not a verified one-to-one clone. The original app appears to include game-injection/kernel-exploit functionality; that behavior is intentionally not implemented here.

## Open in Xcode
Open `LUMINAExternal.xcodeproj` in Xcode. Select a development Team under Signing & Capabilities, then build/run on an iOS simulator or device. This project file is a reconstructed starter and has not been compiled in this environment.

## IPA metadata recovered
- Display name: LUMINA EXTERNAL
- Version: 2.1.1 (build 2)
- Minimum iOS: 16.0
- URL scheme: `xosexternalapp`
- Document extension: `.onyx`
- Original bundle identifier in supplied IPA: `com.apple.mobile.MobileHouseArrest`

The reconstructed project uses a new bundle identifier and does not copy the original signing identity.
