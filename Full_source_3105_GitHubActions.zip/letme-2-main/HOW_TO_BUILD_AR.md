# بناء OGIOS إلى IPA عبر GitHub Actions

## مهم
هذا مشروع Xcode أصلي (Swift / Objective-C)، وليس مشروع Expo أو React Native. لذلك بوت Expo المذكور لن يقبله حتى لو أعدنا ضغطه بصيغة ZIP.

## خطوات البناء من iPhone
1. ارفع مجلد المشروع `letme-2-main` إلى مستودع GitHub جديد (يمكنك رفع ملف ZIP ثم فك ضغطه داخل المستودع من واجهة GitHub إذا كانت متاحة، أو استخدام تطبيق/موقع GitHub على الهاتف).
2. تأكد أن الملف التالي موجود في المستودع:
   `.github/workflows/objective-c-xcode.yml`
3. افتح تبويب **Actions** في المستودع.
4. اختر **Build unsigned IPA** ثم **Run workflow**.
5. اترك الإعدادات الافتراضية كما هي، ثم شغّل البناء.
6. عند نجاح البناء، افتح تشغيل Workflow وانزل إلى **Artifacts** ثم نزّل `OGIOS-unsigned-ipa`.

## التوقيع والتثبيت
الـ IPA الناتج **غير موقّع** لأن إعدادات شهادة Apple وملف provisioning لم تُقدّم. لن يكون قابلاً للتثبيت مباشرة قبل توقيعه بشهادة صالحة. لا تضع شهادة التوقيع أو كلمة مرورها داخل ملفات المشروع أو المستودع.

## معلومات المشروع
- Xcode project: `ThreeOneOSFive.xcodeproj`
- Scheme: `OGIOS`
- Product: `OGIOS`
- Minimum iOS target: 16.0

إذا فشل البناء، نزّل Artifact الخاص باسم `OGIOS-build-log` وراجع سجل Xcode لمعرفة الخطأ. هذا الملف يجهّز البناء عبر GitHub Actions فقط؛ لا يحوّل المشروع إلى Expo ولا يضمن نجاح البناء أو التوقيع.
